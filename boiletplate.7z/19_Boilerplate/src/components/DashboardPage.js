import React from 'react';

const DashboardPage = () => (
  <div>
    Dashboard page content
  </div>
);

export default DashboardPage;
